#!/bin/bash

../imp5Converter --h reference.bcf --r 20 --o reference.imp5
