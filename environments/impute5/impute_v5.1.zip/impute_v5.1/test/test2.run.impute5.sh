#!/bin/bash

../impute5 --h reference.imp5 --g target.bcf --r 20 --m chr20.b37.gmap.gz --o imputed.vcf.gz
